'use client';
import Link from 'next/link';
import React from 'react';

export default function Header() {
  return (
    <header>
      <nav className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-slate-100" aria-label="Main navigation">
        <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
          <div className="text-2xl font-black text-slate-900 tracking-tighter italic">
            DUBAI<span className="text-blue-600">CONCIERGE</span>
          </div>

          <div className="hidden md:flex space-x-10 text-sm font-bold uppercase tracking-widest text-slate-600">
            <a href="#home" className="nav-link active py-2 transition" data-page="home" aria-current="page">Home</a>
            <a href="#packages" className="nav-link py-2 transition" data-page="packages">Packages</a>
            <a href="#guide" className="nav-link py-2 transition" data-page="guide">Survival Guide</a>
          </div>

          <button type="button" className="bg-slate-900 text-white px-8 py-3 rounded-full text-sm font-bold hover:bg-blue-600 transition shadow-lg">
            BOOK CONSULTATION
          </button>
        </div>
      </nav>
    </header>
  );
}