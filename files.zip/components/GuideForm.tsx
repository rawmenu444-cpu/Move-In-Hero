'use client';
import React, { useState } from 'react';

export default function GuideForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle'|'sending'|'success'|'error'>('idle');
  const [message, setMessage] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);

    if (!name.trim() || !email.trim()) {
      setMessage('Please complete both fields.');
      setStatus('error');
      return;
    }

    setStatus('sending');
    try {
      const res = await fetch('/api/request-guide', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email })
      });

      if (!res.ok) throw new Error('Network error');
      const payload = await res.json();
      setStatus('success');
      setMessage('Thanks — the guide will open in a new tab or be emailed to you.');

      if (payload?.pdfUrl) {
        window.open(payload.pdfUrl, '_blank', 'noopener');
      }

      setName('');
      setEmail('');
    } catch (err) {
      setStatus('error');
      setMessage('Sorry — something went wrong. Please try again later.');
    }
  }

  return (
    <div className="bg-slate-50 p-8 rounded-3xl border border-slate-200">
      <h4 className="font-bold mb-4">Enter your details for the PDF</h4>
      <form id="guide-form" onSubmit={handleSubmit} noValidate>
        <div className="mb-4">
          <label htmlFor="fullName" className="sr-only">Full Name</label>
          <input id="fullName" name="fullName" value={name} onChange={(e) => setName(e.target.value)}
            type="text" placeholder="Full Name" required
            className="w-full mb-4 px-6 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" />
        </div>

        <div className="mb-6">
          <label htmlFor="email" className="sr-only">Email Address</label>
          <input id="email" name="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)}
            placeholder="Email Address" required
            className="w-full px-6 py-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none" />
        </div>

        <button type="submit" disabled={status === 'sending'} className="w-full py-4 bg-slate-900 text-white rounded-xl font-bold text-lg hover:bg-blue-600 transition">
          {status === 'sending' ? 'Sending…' : 'DOWNLOAD THE GUIDE'}
        </button>

        <div role="status" aria-live="polite" className="mt-4">
          {message && (
            <p className={status === 'error' ? 'text-red-600' : 'text-slate-600'}>{message}</p>
          )}
        </div>
      </form>
    </div>
  );
}