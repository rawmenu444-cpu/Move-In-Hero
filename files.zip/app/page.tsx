import React from 'react';
import Image from 'next/image';
import Header from '../components/Header';
import GuideForm from '../components/GuideForm';

export default function Home() {
  return (
    <>
      <Header />
      <main id="main-content" className="max-w-full">
        {/* Home section */}
        <section id="home" className="page block" aria-labelledby="home-heading">
          <div className="relative h-[85vh] flex items-center px-6 overflow-hidden bg-slate-900">
            <div className="absolute inset-0 opacity-40" aria-hidden="true">
              <Image
                src="https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1920"
                alt="Dubai skyline at sunset behind modern buildings"
                fill
                className="object-cover"
                priority
              />
            </div>

            <div className="relative max-w-7xl mx-auto w-full z-10 text-white">
              <span className="text-blue-400 font-bold tracking-[0.3em] uppercase mb-4 block">Exclusive Relocation Support</span>
              <h1 id="home-heading" className="text-6xl md:text-8xl mb-8 leading-tight">Land in Dubai.<br /><span className="italic">Already Home.</span></h1>
              <p className="text-xl max-w-xl text-slate-300 mb-10 leading-relaxed">We manage your DEWA, Ejari, and essentials before you even touch down. Experience the "First 48 Hours" without the stress.</p>
              <div className="flex gap-4">
                <a href="#packages" data-page="packages" className="inline-block bg-blue-600 px-10 py-4 rounded-full font-bold text-lg hover:scale-105 transition text-white">Explore Services</a>
                <a href="#guide" data-page="guide" className="inline-block bg-white/10 backdrop-blur-md border border-white/20 px-10 py-4 rounded-full font-bold text-lg hover:bg-white/20 transition text-white">Get Free Guide</a>
              </div>
            </div>
          </div>
        </section>

        {/* Packages */}
        <section id="packages" className="page pt-20 pb-32" aria-labelledby="packages-heading">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-20">
              <h2 id="packages-heading" className="text-5xl mb-4">Tailored Settlement Tiers</h2>
              <p className="text-slate-500 max-w-2xl mx-auto">Choose the level of support that fits your move. From digital essentials to full-service medical and school placement.</p>
            </div>

            <div className="grid lg:grid-cols-3 gap-10">
              <article className="bg-white p-10 rounded-[2rem] border border-slate-100 shadow-xl shadow-slate-200/50" aria-labelledby="starter-title">
                <h3 id="starter-title" className="text-2xl font-serif mb-2">The Starter</h3>
                <div className="text-blue-600 font-bold mb-6 italic text-sm">Digital & Utility Foundation</div>
                <ul className="space-y-4 text-slate-600 mb-10">
                  <li className="flex items-center">✓ DEWA & Ejari Registration</li>
                  <li className="flex items-center">✓ Wi-Fi & SIM Setup</li>
                  <li className="flex items-center">✓ Essential Area Guide</li>
                </ul>
                <button type="button" className="w-full py-4 bg-slate-50 border-2 border-slate-900 text-slate-900 rounded-2xl font-bold hover:bg-slate-900 hover:text-white transition">INQUIRE NOW</button>
              </article>

              <article className="bg-slate-900 p-10 rounded-[2rem] text-white shadow-2xl relative" aria-labelledby="hero-title">
                <div className="absolute -top-5 right-10 bg-blue-600 px-6 py-2 rounded-full text-xs font-black tracking-widest uppercase">Signature</div>
                <h3 id="hero-title" className="text-2xl font-serif mb-2">The Move-In Hero</h3>
                <div className="text-blue-400 font-bold mb-6 italic text-sm">Full Arrival Comfort</div>
                <ul className="space-y-4 text-slate-300 mb-10">
                  <li className="flex items-center">✨ Everything in Starter</li>
                  <li className="flex items-center">✨ Deep Cleaning & Handyman</li>
                  <li className="flex items-center">✨ Grocery Stock-up (Fresh Essentials)</li>
                </ul>
                <button type="button" className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-500 transition">MOST POPULAR</button>
              </article>

              <article className="bg-white p-10 rounded-[2rem] border border-slate-100 shadow-xl shadow-slate-200/50" aria-labelledby="elite-title">
                <h3 id="elite-title" className="text-2xl font-serif mb-2">The Elite</h3>
                <div className="text-blue-600 font-bold mb-6 italic text-sm">White-Glove Integration</div>
                <ul className="space-y-4 text-slate-600 mb-10">
                  <li className="flex items-center">🏅 Everything in Hero</li>
                  <li className="flex items-center">🏅 School Search & Tours</li>
                  <li className="flex items-center">🏅 Emirates ID & Medical Escort</li>
                  <li className="flex items-center">🏅 Bank Account Opening Guidance</li>
                </ul>
                <button type="button" className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-blue-600 transition">GO ELITE</button>
              </article>
            </div>
          </div>
        </section>

        {/* Guide */}
        <section id="guide" className="page py-20" aria-labelledby="guide-heading">
          <div className="max-w-4xl mx-auto px-6 bg-white rounded-[3rem] p-12 md:p-24 shadow-2xl border border-slate-50">
            <div className="text-center">
              <div className="inline-block px-4 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold mb-6">FREE RESOURCE</div>
              <h2 id="guide-heading" className="text-5xl mb-8 font-serif">The "First 48 Hours" Dubai Survival Guide</h2>
              <p className="text-lg text-slate-500 mb-12">Our proprietary roadmap to landing in the UAE without the confusion. Includes a checklist for documents, transport, and immediate housing setups.</p>

              <GuideForm />
            </div>
          </div>
        </section>
      </main>

      <footer className="py-20 border-t border-slate-200" role="contentinfo">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center opacity-60">
          <p className="text-sm">© 2026 Dubai Settling-In Concierge. Your premium partner in the UAE.</p>
          <div className="flex space-x-6 mt-6 md:mt-0 text-xs font-bold uppercase tracking-widest">
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
            <a href="#">Instagram</a>
          </div>
        </div>
      </footer>
    </>
  );
}