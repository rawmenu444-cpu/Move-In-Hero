import './globals.css';
import React from 'react';
import { Playfair_Display, Plus_Jakarta_Sans } from 'next/font/google';

const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['700'],
  variable: '--font-playfair',
  display: 'swap'
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '600'],
  variable: '--font-sans',
  display: 'swap'
});

export const metadata = {
  title: 'Dubai Settling-In Concierge | Premium Relocation',
  description: 'Premium Dubai relocation support — DEWA, Ejari, SIM & Wi‑Fi setup, cleaning, school search, Emirates ID accompaniment and more. Land in Dubai, already home.',
  openGraph: {
    title: 'Dubai Settling-In Concierge | Premium Relocation',
    description: 'Premium Dubai relocation support — DEWA, Ejari, SIM & Wi‑Fi setup, cleaning, school search, Emirates ID accompaniment and more.',
    url: 'https://yourdomain.example/',
    siteName: 'Dubai Settling-In Concierge',
    images: [
      {
        url: 'https://yourdomain.example/og-image-1200x630.jpg',
        width: 1200,
        height: 630
      }
    ],
    type: 'website'
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Dubai Settling-In Concierge',
    description: 'Premium Dubai relocation support — DEWA, Ejari, SIM & Wi‑Fi setup, cleaning, school search, Emirates ID accompaniment and more.',
    images: ['https://yourdomain.example/og-image-1200x630.jpg']
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Dubai Settling-In Concierge",
    "url": "https://yourdomain.example/",
    "logo": "https://yourdomain.example/logo.png",
    "sameAs": [
      "https://www.instagram.com/yourprofile"
    ]
  };

  return (
    <html lang="en" className={`${playfair.variable} ${plusJakarta.variable}`}>
      <head>
        <meta name="theme-color" content="#0f172a" />
        {/* If you want to self-host fonts later, replace next/font usage */}
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        {/* Open Graph/Twitter will be merged from metadata in Next; JSON-LD below */}
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </head>
      <body>
        <a href="#main-content" className="skip-link">Skip to main content</a>
        {children}
      </body>
    </html>
  );
}