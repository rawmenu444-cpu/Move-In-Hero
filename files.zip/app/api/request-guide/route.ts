import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// If SENDGRID_API_KEY is present we will send an email to the requester with a link to the PDF.
// Otherwise we return a json payload with pdfUrl so the client can open it directly.

export async function POST(request: Request) {
  try {
    const data = await request.json();
    const name = String(data?.name ?? '').trim();
    const email = String(data?.email ?? '').trim();

    if (!name || !email) {
      return NextResponse.json({ error: 'Missing name or email' }, { status: 400 });
    }

    const pdfUrl = '/first-48-guide.pdf'; // put your PDF in /public or provide a hosted URL

    const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
    const SENDGRID_FROM = process.env.SENDGRID_FROM; // e.g. "info@yourdomain.com"

    if (SENDGRID_API_KEY && SENDGRID_FROM) {
      // Lazy import to avoid requiring @sendgrid/mail when not used in dev
      const sgMail = (await import('@sendgrid/mail')).default;
      sgMail.setApiKey(SENDGRID_API_KEY);

      const msg = {
        to: email,
        from: SENDGRID_FROM,
        subject: 'Your "First 48 Hours" Dubai Survival Guide',
        text: `Hi ${name},\n\nThanks for requesting our "First 48 Hours" guide. You can download it here: ${process.env.NEXT_PUBLIC_SITE_URL ?? 'https://yourdomain.example'}${pdfUrl}\n\nIf you have any questions, reply to this email.\n\n— Dubai Settling-In Concierge`,
        html: `<p>Hi ${name},</p>
               <p>Thanks for requesting our <strong>"First 48 Hours"</strong> guide. You can download it here: <a href="${process.env.NEXT_PUBLIC_SITE_URL ?? 'https://yourdomain.example'}${pdfUrl}">Download the guide</a></p>
               <p>If you have any questions, reply to this email.</p>
               <p>— Dubai Settling-In Concierge</p>`
      };

      try {
        await sgMail.send(msg);
        // Optionally, you could also BCC an internal address
        return NextResponse.json({ success: true, pdfUrl }, { status: 200 });
      } catch (sendErr) {
        // If sending fails, return the pdfUrl so the client can still open it
        console.error('SendGrid error:', sendErr);
        return NextResponse.json({ success: false, error: 'Email failed, returning PDF link', pdfUrl }, { status: 200 });
      }
    }

    // No SendGrid configured — return pdfUrl so client can handle opening/downloading
    return NextResponse.json({ pdfUrl }, { status: 200 });
  } catch (err) {
    console.error('API error', err);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}