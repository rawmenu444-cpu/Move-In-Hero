# Dubai Settling-In Concierge — Next.js + Tailwind Starter (with SendGrid & CI)

This repo is a production-ready conversion of your landing page to Next.js (App Router) + Tailwind, now with:

- next/font/google usage for Playfair Display and Plus Jakarta Sans
- JSON-LD & improved Open Graph / Twitter metadata
- /api/request-guide POST endpoint that will email the guide via SendGrid (if credentials provided) and return a PDF URL
- GitHub Actions workflow to build and optionally deploy to Vercel

Quick start:
1. Install
   - npm install
2. Development
   - npm run dev
3. Build
   - npm run build
   - npm start

Place your PDF at `public/first-48-guide.pdf` (or change the URL in `app/api/request-guide/route.ts`).

Environment variables (create a .env.local for local dev):
- SENDGRID_API_KEY (optional — if set, the API will send an email with the guide link)
- SENDGRID_FROM (required if SENDGRID_API_KEY set, e.g. "info@yourdomain.com")
- VERCEL_TOKEN (optional for CI deploy)
- VERCEL_ORG_ID (optional for CI deploy)
- VERCEL_PROJECT_ID (optional for CI deploy)

GitHub Actions:
- A workflow is included at `.github/workflows/ci.yml`. It will run install & build on push.
- If `VERCEL_TOKEN`, `VERCEL_ORG_ID`, and `VERCEL_PROJECT_ID` are set in repository secrets, the workflow will also deploy to Vercel.

Notes:
- You can replace the SendGrid logic with any other transactional provider; the route checks for SENDGRID_API_KEY and falls back to returning the PDF URL if not provided.
- Consider switching fonts to an exported font binary (self-host) for full control.